package org.springframework.beans;

public abstract interface PropertyEditorRegistrar
{
  public abstract void registerCustomEditors(PropertyEditorRegistry paramPropertyEditorRegistry);
}

/* Location:           D:\repo\org\springframework\spring-beans\4.3.2.RELEASE\spring-beans-4.3.2.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyEditorRegistrar
 * JD-Core Version:    0.6.2
 */