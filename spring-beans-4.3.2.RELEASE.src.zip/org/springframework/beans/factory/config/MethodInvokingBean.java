/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class MethodInvokingBean extends ArgumentConvertingMethodInvoker
/*     */   implements BeanClassLoaderAware, BeanFactoryAware, InitializingBean
/*     */ {
/*  69 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private ConfigurableBeanFactory beanFactory;
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  76 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveClassName(String className) throws ClassNotFoundException
/*     */   {
/*  81 */     return ClassUtils.forName(className, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  86 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/*  87 */       this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   protected TypeConverter getDefaultTypeConverter()
/*     */   {
/*  98 */     if (this.beanFactory != null) {
/*  99 */       return this.beanFactory.getTypeConverter();
/*     */     }
/*     */ 
/* 102 */     return super.getDefaultTypeConverter();
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 109 */     prepare();
/* 110 */     invokeWithTargetException();
/*     */   }
/*     */ 
/*     */   protected Object invokeWithTargetException()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 119 */       return invoke();
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 122 */       if ((ex.getTargetException() instanceof Exception)) {
/* 123 */         throw ((Exception)ex.getTargetException());
/*     */       }
/* 125 */       if ((ex.getTargetException() instanceof Error)) {
/* 126 */         throw ((Error)ex.getTargetException());
/*     */       }
/* 128 */       throw ex;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\repo\org\springframework\spring-beans\4.3.2.RELEASE\spring-beans-4.3.2.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.MethodInvokingBean
 * JD-Core Version:    0.6.2
 */