package org.springframework.beans.factory;

public abstract interface SmartInitializingSingleton
{
  public abstract void afterSingletonsInstantiated();
}

/* Location:           D:\repo\org\springframework\spring-beans\4.3.2.RELEASE\spring-beans-4.3.2.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.SmartInitializingSingleton
 * JD-Core Version:    0.6.2
 */