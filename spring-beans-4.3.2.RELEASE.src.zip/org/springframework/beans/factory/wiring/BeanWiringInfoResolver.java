package org.springframework.beans.factory.wiring;

public abstract interface BeanWiringInfoResolver
{
  public abstract BeanWiringInfo resolveWiringInfo(Object paramObject);
}

/* Location:           D:\repo\org\springframework\spring-beans\4.3.2.RELEASE\spring-beans-4.3.2.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.wiring.BeanWiringInfoResolver
 * JD-Core Version:    0.6.2
 */